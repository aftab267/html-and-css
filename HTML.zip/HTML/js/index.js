// function myFunction(){
//     document.getElementById("demo").innerHTML = "Hello JavaScript!"
// }

const cars=["volvo","toyota","sujuki"];
function myFunction(){
document.getElementById('demo').innerHTML=cars[0];
}